EcoWatch Pune Android wrapper source

This is an Android Studio/Gradle project intended to package the existing
EcoWatch Pune Streamlit website in an Android WebView with JavaScript and DOM
storage enabled. It does not replace or modify the website or its Supabase data.

Website loaded:
https://ecowatch-pune-plastic.streamlit.app/

Important:
- This source is a build starting point, not a tested/released APK.
- Build it with Android Gradle Plugin 8.7.3, Gradle 8.9, and JDK 17.
- The app requests camera and location permissions because the website uses
  camera capture and browser geolocation.
- Test the APK thoroughly before distributing it to students. WebView behavior
  can vary by Android System WebView version.
- This wrapper does not change the Streamlit website's own interface.
